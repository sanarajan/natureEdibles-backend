import { inject, injectable } from 'tsyringe';
import { IUpdateDietPlanUseCase } from '../../interfaces/use-cases/diet-plan/IDietPlanUseCases';
import { IDietPlanRepository } from '../../../domain/repositories/IDietPlanRepository';
import { DietPlan, DietPlanSection } from '../../../domain/entities/DietPlan';

@injectable()
export class UpdateDietPlanUseCase implements IUpdateDietPlanUseCase {
    constructor(
        @inject('IDietPlanRepository') private dietPlanRepo: IDietPlanRepository
    ) {}

    async execute(id: string, updates: Partial<DietPlan>): Promise<DietPlan | null> {
        const existing = await this.dietPlanRepo.findById(id);
        if (!existing) {
            throw new Error('Diet Plan not found');
        }

        if (updates.startDate) {
            const newStartDate = new Date(updates.startDate);
            const originalStartDate = new Date(existing.originalStartDate);
            
            // Normalize dates to ignore time components for comparison
            newStartDate.setHours(0, 0, 0, 0);
            originalStartDate.setHours(0, 0, 0, 0);

            if (newStartDate < originalStartDate) {
                throw new Error('Edited Start Date cannot be earlier than the Original Start Date');
            }
        }

        if (updates.sections && updates.durationValue) {
            if (updates.sections.length > updates.durationValue) {
                throw new Error(`Number of sections cannot exceed duration value (${updates.durationValue})`);
            }
        } else if (updates.sections) {
            if (updates.sections.length > existing.durationValue) {
                throw new Error(`Number of sections cannot exceed duration value (${existing.durationValue})`);
            }
        }

        // Do not allow overwriting originalStartDate
        if ('originalStartDate' in updates) {
            delete updates.originalStartDate;
        }
        
        // Ensure consultationId and customerId cannot be changed
        if ('consultationId' in updates) delete updates.consultationId;
        if ('customerId' in updates) delete updates.customerId;

        return await this.dietPlanRepo.update(id, updates);
    }
}
