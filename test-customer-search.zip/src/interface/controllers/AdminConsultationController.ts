import { Request, Response } from 'express';
import { inject, injectable } from 'tsyringe';
import { IGetAdminConsultationsUseCase, IUpdateConsultationStatusUseCase, IGetConsultationByIdUseCase } from '../../application/interfaces/use-cases/consultation/IConsultationBookingUseCases';
import { IGetConsultationSettingsUseCase, IUpdateConsultationSettingsUseCase } from '../../application/interfaces/use-cases/consultation/IConsultationSettingsUseCases';
import { IUpdateConsultationDateUseCase } from '../../application/interfaces/use-cases/consultation/IConsultationBookingUseCases';

@injectable()
export class AdminConsultationController {
    constructor(
        @inject('IGetAdminConsultationsUseCase') private getAdminConsultationsUseCase: IGetAdminConsultationsUseCase,
        @inject('IUpdateConsultationStatusUseCase') private updateConsultationStatusUseCase: IUpdateConsultationStatusUseCase,
        @inject('IGetConsultationSettingsUseCase') private getConsultationSettingsUseCase: IGetConsultationSettingsUseCase,
        @inject('IUpdateConsultationSettingsUseCase') private updateConsultationSettingsUseCase: IUpdateConsultationSettingsUseCase,
        @inject('IGetConsultationByIdUseCase') private getConsultationByIdUseCase: IGetConsultationByIdUseCase,
        @inject('IUpdateConsultationDateUseCase') private updateConsultationDateUseCase: IUpdateConsultationDateUseCase
    ) {}

    async getConsultations(req: Request, res: Response) {
        try {
            const page = parseInt(req.query.page as string) || 1;
            const limit = parseInt(req.query.limit as string) || 10;
            const status = req.query.status as string;
            const search = req.query.search as string;

            const filters = { status, search };
            const result = await this.getAdminConsultationsUseCase.execute(filters, page, limit);
            return res.status(200).json({ success: true, message: 'Consultations fetched successfully', data: result });
        } catch (error: any) {
            return res.status(500).json({ success: false, message: error.message || 'Error fetching consultations' });
        }
    }

    async getConsultationById(req: Request, res: Response) {
        try {
            const id = req.params.id as string;
            const consultation = await this.getConsultationByIdUseCase.execute(id);
            if (!consultation) {
                return res.status(404).json({ success: false, message: 'Consultation not found' });
            }
            return res.status(200).json({ success: true, message: 'Consultation fetched successfully', data: consultation });
        } catch (error: any) {
            return res.status(500).json({ success: false, message: error.message || 'Error fetching consultation' });
        }
    }

    async updateConsultation(req: Request, res: Response) {
        try {
            const id = req.params.id as string;
            const updates = req.body;

            if (updates.status === 'REJECTED' && (!updates.rejectionReason || updates.rejectionReason.trim().length < 3)) {
                return res.status(400).json({ success: false, message: 'Rejection reason is required and must be at least 3 characters long.' });
            }

            const updated = await this.updateConsultationStatusUseCase.execute(id, updates);
            if (!updated) {
                return res.status(404).json({ success: false, message: 'Consultation not found' });
            }
            return res.status(200).json({ success: true, message: 'Consultation updated successfully', data: updated });
        } catch (error: any) {
            if (
                error.message === 'This consultation booking status has already been finalized.' ||
                error.message === 'This consultation booking status has already been finalized as rejected.' ||
                error.message === 'This consultation booking has already been completed.' ||
                error.message === 'An approved consultation can only be marked as COMPLETED.' ||
                error.message === 'Mark as Refunded is allowed only when consultation is REJECTED and payment is REFUND_PENDING.' ||
                error.message === 'REFUND_PENDING is allowed only when rejecting a PAID booking.'
            ) {
                return res.status(400).json({ success: false, message: error.message });
            }
            return res.status(500).json({ success: false, message: error.message || 'Error updating consultation' });
        }
    }

    async updateConsultationDate(req: Request, res: Response) {
        try {
            const id = req.params.id as string;
            const { appointmentDate } = req.body;

            if (!appointmentDate) {
                return res.status(400).json({ success: false, message: 'Appointment date is required.' });
            }

            const updated = await this.updateConsultationDateUseCase.execute(id, appointmentDate);
            if (!updated) {
                return res.status(404).json({ success: false, message: 'Consultation not found' });
            }
            return res.status(200).json({ success: true, message: 'Consultation date updated successfully', data: updated });
        } catch (error: any) {
            return res.status(400).json({ success: false, message: error.message || 'Error updating consultation date' });
        }
    }

    async getSettings(req: Request, res: Response) {
        try {
            const settings = await this.getConsultationSettingsUseCase.execute();
            return res.status(200).json({ success: true, message: 'Settings fetched successfully', data: settings });
        } catch (error: any) {
            return res.status(500).json({ success: false, message: error.message || 'Error fetching settings' });
        }
    }

    async updateSettings(req: Request, res: Response) {
        try {
            const settings = req.body;
            const updated = await this.updateConsultationSettingsUseCase.execute(settings);
            return res.status(200).json({ success: true, message: 'Settings updated successfully', data: updated });
        } catch (error: any) {
            return res.status(500).json({ success: false, message: error.message || 'Error updating settings' });
        }
    }
}
