import { Request, Response } from 'express';
import { inject, injectable } from 'tsyringe';
import { 
    IGetDietPlansByCustomerIdUseCase,
    IGetDietPlanByConsultationIdUseCase 
} from '../../application/interfaces/use-cases/diet-plan/IDietPlanUseCases';

@injectable()
export class UserDietPlanController {
    constructor(
        @inject('IGetDietPlansByCustomerIdUseCase') private getDietPlansByCustomerIdUseCase: IGetDietPlansByCustomerIdUseCase,
        @inject('IGetDietPlanByConsultationIdUseCase') private getDietPlanByConsultationIdUseCase: IGetDietPlanByConsultationIdUseCase
    ) {}

    async getMyDietPlans(req: Request, res: Response) {
        try {
            const customerId = (req as any).user.id; // assuming user auth middleware attaches user to req
            const plans = await this.getDietPlansByCustomerIdUseCase.execute(customerId);
            return res.status(200).json({ success: true, message: 'Diet Plans fetched successfully', data: plans });
        } catch (error: any) {
            return res.status(400).json({ success: false, message: error.message || 'Error fetching Diet Plans' });
        }
    }

    async getDietPlanByConsultation(req: Request, res: Response) {
        try {
            const customerId = (req as any).user.id;
            const consultationId = req.params.consultationId as string;
            const plan = await this.getDietPlanByConsultationIdUseCase.execute(consultationId);
            
            if (!plan) {
                return res.status(404).json({ success: false, message: 'Diet Plan not found' });
            }

            if (plan.customerId !== customerId) {
                return res.status(403).json({ success: false, message: 'Access denied' });
            }

            return res.status(200).json({ success: true, message: 'Diet Plan fetched successfully', data: plan });
        } catch (error: any) {
            return res.status(400).json({ success: false, message: error.message || 'Error fetching Diet Plan' });
        }
    }
}
