export class DietPlanSection {
    constructor(
        public sequence: number,
        public label: string,
        public description: string
    ) {}
}

export class DietPlan {
    constructor(
        public readonly id: string,
        public consultationId: string,
        public customerId: string,
        public durationType: "days" | "weeks" | "months",
        public durationValue: number,
        public originalStartDate: Date,
        public startDate: Date,
        public sections: DietPlanSection[],
        public createdBy: string,
        public readonly createdAt: Date = new Date(),
        public updatedAt: Date = new Date()
    ) {}
}
