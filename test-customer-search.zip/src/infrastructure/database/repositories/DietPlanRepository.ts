import { injectable } from 'tsyringe';
import { IDietPlanRepository } from '../../../domain/repositories/IDietPlanRepository';
import { DietPlan, DietPlanSection } from '../../../domain/entities/DietPlan';
import { DietPlanModel, IDietPlanDocument } from '../models/DietPlanModel';

@injectable()
export class DietPlanRepository implements IDietPlanRepository {
    async create(dietPlan: DietPlan): Promise<DietPlan> {
        const newPlan = new DietPlanModel(dietPlan);
        const saved = await newPlan.save();
        return this.mapToEntity(saved);
    }

    async findById(id: string): Promise<DietPlan | null> {
        const doc = await DietPlanModel.findById(id);
        return doc ? this.mapToEntity(doc) : null;
    }

    async findByConsultationId(consultationId: string): Promise<DietPlan | null> {
        const doc = await DietPlanModel.findOne({ consultationId });
        return doc ? this.mapToEntity(doc) : null;
    }

    async findByCustomerId(customerId: string): Promise<DietPlan[]> {
        const docs = await DietPlanModel.find({ customerId }).sort({ createdAt: -1 });
        return docs.map(doc => this.mapToEntity(doc));
    }

    async update(id: string, updates: Partial<DietPlan>): Promise<DietPlan | null> {
        const doc = await DietPlanModel.findByIdAndUpdate(id, updates, { new: true });
        return doc ? this.mapToEntity(doc) : null;
    }

    private mapToEntity(doc: IDietPlanDocument): DietPlan {
        return new DietPlan(
            doc._id.toString(),
            doc.consultationId.toString(),
            doc.customerId.toString(),
            doc.durationType,
            doc.durationValue,
            doc.originalStartDate,
            doc.startDate,
            doc.sections.map(s => new DietPlanSection(s.sequence, s.label, s.description)),
            doc.createdBy.toString(),
            doc.createdAt,
            doc.updatedAt
        );
    }
}
