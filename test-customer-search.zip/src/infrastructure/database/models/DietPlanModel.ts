import mongoose, { Schema, Document } from 'mongoose';

export interface IDietPlanSection {
    sequence: number;
    label: string;
    description: string;
}

export interface IDietPlanDocument extends Document {
    consultationId: mongoose.Types.ObjectId;
    customerId: mongoose.Types.ObjectId;
    durationType: "days" | "weeks" | "months";
    durationValue: number;
    originalStartDate: Date;
    startDate: Date;
    sections: IDietPlanSection[];
    createdBy: mongoose.Types.ObjectId;
    createdAt: Date;
    updatedAt: Date;
}

const DietPlanSectionSchema: Schema = new Schema({
    sequence: { type: Number, required: true },
    label: { type: String, required: true },
    description: { type: String, required: false, default: '' }
}, { _id: false });

const DietPlanSchema: Schema = new Schema({
    consultationId: { type: Schema.Types.ObjectId, ref: 'ConsultationBooking', required: true },
    customerId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    durationType: { type: String, enum: ['days', 'weeks', 'months'], required: true },
    durationValue: { type: Number, required: true },
    originalStartDate: { type: Date, required: true },
    startDate: { type: Date, required: true },
    sections: { type: [DietPlanSectionSchema], required: true },
    createdBy: { type: Schema.Types.ObjectId, ref: 'User', required: true }
}, { timestamps: true });

export const DietPlanModel = mongoose.models.DietPlan || mongoose.model<IDietPlanDocument>('DietPlan', DietPlanSchema);
